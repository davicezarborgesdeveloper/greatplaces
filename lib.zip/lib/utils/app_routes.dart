class AppRoutes {
  static const String PLACE_FORM = '/place-form';
}
